/* inststr.h ..... change argv[0].
 *
 * $Id: inststr.h,v 1.1 2000/12/23 08:19:51 scott Exp $
 */

void inststr(int argc, char **argv, char **envp, char *src);
