/* version.h ..... keep track of package version number. 
 *                 C. Scott Ananian <cananian@alumni.princeton.edu>
 *
 * $Id: version.h,v 1.1 2000/12/23 08:19:51 scott Exp $
 */

#ifndef INC_VERSION_H
#define INC_VERSION_H
extern const char * version;
#endif /* INC_VERSION_H */
